import frappe 
import base64, time
from rentals.methods.get_doc_name import get_customer
from rentals.methods.clean_number import remove_non_numeric
from rentals.methods.message_log import add_message_log
from rentals.objects.WhatsappServiceConfig import WhatsappService

@frappe.whitelist(allow_guest=False)
def send_message(name):

    getName = get_customer(name).name # the get_customer function returns the whole record with the passed name (e.g of passed name 'sicfm68bqf')
    getReceiverPhoneNumber = remove_non_numeric(get_customer(name).receiver_phone_number) # the remove_non_numeric function returns a converted phone number (e.g from '+967-770871484' to '967770871484') to be undrestood by wppconnect
    getSenderPhoneNumber = remove_non_numeric(get_customer(name).phone_number) #sender phone number is only used for the message log
    getMessage = get_customer(name).message_url
    getMessageImage = get_customer(name).message_image
    base64_image = None
    
    whatsappService = WhatsappService(getName) # instance of WhatsappService object

    if getMessageImage:
        
        image_path = frappe.get_site_path('files',getMessageImage) #this gets the path of a picture (locally) i will change it
        image_path ="/home/mohammed/frappe-bench/sites/site1.local/public"+image_path

        with open(image_path, "rb") as image_file:
            base64_image ='data:image/jpeg;base64,'+base64.b64encode(image_file.read()).decode('utf-8') # this changes the image to base64 string


    add_message_log(getSenderPhoneNumber, getReceiverPhoneNumber, frappe.utils.now(), getMessage, getMessageImage)
    # time.sleep(10)
    result = whatsappService.send_whatsapp_message(getReceiverPhoneNumber, False, False, getMessage, getMessageImage, base64_image)
    return{
        "result":f"This is the result: {result}" # only to see the result in postman
    }
# http://127.0.0.1:8001/api/method/rentals.apis.api.send_message

