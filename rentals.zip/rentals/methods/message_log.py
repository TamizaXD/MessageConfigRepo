import frappe

def add_message_log(sender_number, receiver_number, timestamp, message, message_path = None, status = "Pending"): #Pending will be changed

    if message_path:
        target_doctype = frappe.get_doc({
            'doctype': 'Message Log',
            'sender_number': sender_number,
            'receiver_number': receiver_number,
            'timestamp': timestamp,
            'message': message,
            'message_image': message_path,
            'status':status
        })

    else:
        target_doctype = frappe.get_doc({
            'doctype': 'Message Log',
            'sender_number': sender_number,
            'receiver_number': receiver_number,
            'timestamp': timestamp,
            'message': message,
            'message_image': "No Image",
            'status':status
        })

    add_to_message_log_dt(target_doctype) # this function ensures the record is being inserted and saved in the Message Log Doctype

def add_to_message_log_dt(target):
    target.insert()
    frappe.db.commit()