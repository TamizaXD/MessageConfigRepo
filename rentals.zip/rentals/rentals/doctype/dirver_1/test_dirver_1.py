# Copyright (c) 2024, MN and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestDirver1(FrappeTestCase):
	pass
