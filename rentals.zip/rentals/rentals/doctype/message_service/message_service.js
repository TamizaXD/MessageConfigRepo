// Copyright (c) 2024, MN and contributors
// For license information, please see license.txt
frappe.ui.form.on("Message Service", {
	refresh(frm) {

        frm.add_custom_button(("Send Message"), function(){
            cusotmer_name = frm.doc.name;

            frappe.call({
                method: "rentals.apis.api.send_message?name="+cusotmer_name, //this button triggers the API and take one parameter 'name' to uniquely identify each record in the Message Service Doctype 
            })
            console.log("Message sent!")
        })
	},
    onload: function(frm){
        toggle_section(frm);       
    },

    service_type: function(frm){
        toggle_section(frm);
        frm.save();
    }
});

function toggle_section (frm){

    // to show section use {.df.hidden = 0}
    // to hide section use {.df.hidden = 1}

    if(frm.doc.service_type === 'Both'){

        frm.fields_dict['service_type_sms_section'].df.hidden = 0;
        frm.fields_dict['service_type_whatsapp_section'].df.hidden = 0; 
    }

    else if (frm.doc.service_type === 'SMS') { 

        frm.fields_dict['service_type_sms_section'].df.hidden = 0;      
        frm.fields_dict['service_type_whatsapp_section'].df.hidden = 1; 
        
    } else {
        
        frm.fields_dict['service_type_sms_section'].df.hidden = 1;
        frm.fields_dict['service_type_whatsapp_section'].df.hidden = 0; 
    }
}
