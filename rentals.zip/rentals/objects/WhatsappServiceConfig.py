import frappe
import requests
from rentals.methods.get_doc_name import get_customer, get_wppconnect_url
import urllib.parse


class WhatsappService:
    def __init__(self, name):

        self.name = name
        self.message_service_doc = get_customer(self.name)

        customer = self.message_service_doc
        
        self.session = customer.session
        self.token = customer.auth_token_wam
        self.image_path = customer.message_image
        wppconnect_url = get_wppconnect_url()
        self.baseUrl = urllib.parse.urljoin(wppconnect_url, customer.session)
        # http://192.168.88.30:21444/api/m_noman

        self.headers = { 
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json; charset=utf-8",
        }

    def send_whatsapp_message(self, phone_number, is_group, is_newsletter, message_body, image_path = None, base64 = None): # i am passing all the data for both message with image and not (if there's an image 'image_path' and 'base64' will be changed to the passed values from api.py)
        try:
            if image_path and base64:
                url = f"{self.baseUrl}/send-image"
                #  http://192.168.88.30:21444/api/m_noman/send-image

                data = {
                    "phone": phone_number,
                    "isGroup": is_group,
                    "isNewsletter": is_newsletter,
                    "filename": image_path,
                    "message": message_body,
                    "base64": base64
                }
            else:
                url = f"{self.baseUrl}/send-message"
                # http://192.168.88.30:21444/api/m_noman/send-message

                data = {
                    "phone": phone_number,
                    "isGroup": is_group,
                    "isNewsletter": is_newsletter,
                    "message": message_body
                }

            response = requests.post(url, json=data, headers=self.headers)
            # status = STATUS_CODE_MAP[response.status_code]
            return f"response: {url, data, response.json}" #postman test

        except Exception as e:
            frappe.log_error(f"Exception: {e}")
            return {"status": f"{e}"}
   
# STATUS_CODE_MAP = {
#     200: 'Successful',
#     201: 'Successful',
#     400: 'Bad Request',
#     401: 'Unauthorized',
#     403: 'Forbidden',
#     404: 'Not Found',
#     500: 'Internal Server Error',
#     502: 'Bad Gateway',
#     503: 'Service Unavailable',
# }
